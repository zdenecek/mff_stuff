<?php

return [
	'order' => [ 'name', 'points', 'memes' ],
	'desc' => 'int'
];
