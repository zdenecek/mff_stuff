function maxFreeRect(width, height, rects)
{
	/*
	 * Your code goes here ...
	 */

	const rect = {
		left: 100, top: 100, width: 100, height: 100
	}

	return rect;
}


// In nodejs, this is the way how export is performed.
// In browser, module has to be a global varibale object.
module.exports = { maxFreeRect };
