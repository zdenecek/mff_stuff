<?php

require_once(__DIR__ . '/recodex_lib.php');

/*
 * Your code goes here...
 */

require __DIR__ . '/form_template.html';
