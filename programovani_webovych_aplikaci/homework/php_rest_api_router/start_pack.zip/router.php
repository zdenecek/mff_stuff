<?php

class Router
{
	public function dispatch()
	{
		/*
		 * Your code goes here...
		 */
	}	
}
